ChromeUtils.defineModuleGetter(this, "ExtensionCommon",
                               "resource://gre/modules/ExtensionCommon.jsm");
ChromeUtils.defineModuleGetter(this, "Services",
                               "resource://gre/modules/Services.jsm");

gOnStackAvailableListeners = new Set();

this.stackDump = class extends ExtensionAPI {
  getAPI(context) {
    Cu.reportError("Registering actor!");
    ChromeUtils.registerWindowActor("OpenWPMStackDump", {
      parent: {
        moduleURI: "file:///Users/nhnt11/Dev/OpenWPM/automation/Extension/firefox/src/privileged/stackDump/OpenWPMStackDumpParent.jsm",
      },
      child: {
        moduleURI: "file:///Users/nhnt11/Dev/OpenWPM/automation/Extension/firefox/src/privileged/stackDump/OpenWPMStackDumpChild.jsm",
        observers: ["http-on-opening-request", "document-on-opening-request", "network-monitor-alternate-stack"],
      },
      allFrames: true,
    });
    Cu.reportError("Done!");

    return {
      stackDump: {
        onStackAvailable: new ExtensionCommon.EventManager({
          context: context,
          name: "stackDump.onStackAvailable",
          register: (fire) => {
            let listener = (id, data) => {
              fire.async(id, data);
            };
            gOnStackAvailableListeners.add(listener);
            return () => {
              gOnStackAvailableListeners.delete(listener);
            };
          }
        }).api(),
      },
    };
  }
};
